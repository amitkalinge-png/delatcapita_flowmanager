# tasks/base.py
from abc import ABC, abstractmethod
from models import TaskResult
from typing import Dict, Any


class BaseTask(ABC):
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description

    @abstractmethod
    async def run(self, context: Dict[str, Any]) -> TaskResult:
        pass
