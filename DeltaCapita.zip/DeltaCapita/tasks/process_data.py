# tasks/process_data.py
import asyncio
from tasks.base import BaseTask
from models import TaskResult


class ProcessDataTask(BaseTask):
    async def run(self, context):
        await asyncio.sleep(0.3)

        fetched = (
            context.get("task_results", {})
            .get("task1", {})
            .get("data", {})
            .get("fetched")
        )

        if not fetched:
            return TaskResult(status="failure", message="No data to process")

        total = sum(fetched["items"])
        return TaskResult(status="success", data={"processed": {"sum": total}})
