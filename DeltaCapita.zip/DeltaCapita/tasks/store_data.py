# tasks/store_data.py
import asyncio
import uuid
from tasks.base import BaseTask
from models import TaskResult


class StoreDataTask(BaseTask):
    async def run(self, context):
        await asyncio.sleep(0.2)

        processed = (
            context.get("task_results", {})
            .get("task2", {})
            .get("data", {})
            .get("processed")
        )

        if not processed:
            return TaskResult(status="failure", message="Nothing to store")

        return TaskResult(
            status="success",
            data={"store_id": str(uuid.uuid4())},
            message="Stored successfully",
        )
