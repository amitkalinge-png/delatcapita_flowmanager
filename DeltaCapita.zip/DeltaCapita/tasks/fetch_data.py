# tasks/fetch_data.py
import asyncio
from tasks.base import BaseTask
from models import TaskResult


class FetchDataTask(BaseTask):
    async def run(self, context):
        await asyncio.sleep(0.5)
        data = {"items": [1, 2, 3]}
        return TaskResult(status="success", data={"fetched": data})
